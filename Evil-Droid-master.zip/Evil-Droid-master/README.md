## Evil-Droid Framework . version 0.3 
    Author: Mascerano Bachir [ dev-labs ]

## Legal Disclamer:
    The author does not hold any responsibility for the bad use of this tool,
    remember this is only for educational purpose.

## Description:
    Evil-Droid is a framework that create & generate & embed apk payload to penetrate android platforms
 
## Screenshot:
![pic1](https://i.imgur.com/LczO636.png)

![pic2](https://i.imgur.com/mhXxb5Q.png)

<br /><br />

## Dependencies :
    1 - metasploit-framework
	2 - xterm
	3 - Zenity
	4 - Aapt
	5 - Apktool
	6 - Zipalign

## Download/Config/Usage:
    1? - Download the tool from github
         git clone https://github.com/M4sc3r4n0/Evil-Droid.git

    2? - Set script execution permission
         cd Evil-Droid
         chmod +x evil-droid


    4?- Run Evil-Droid Framework :
       ./evil-droid
         see options bellow	   
      

## video tutorial: 
https://www.youtube.com/watch?v=8u-NHeTdPRE&feature=share old version
